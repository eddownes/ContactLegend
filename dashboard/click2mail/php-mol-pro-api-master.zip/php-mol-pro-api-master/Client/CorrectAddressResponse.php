<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CorrectAddressResponse {
  /* ArrayOfAnyType */
  public $CorrectAddressResult;
}

?>
