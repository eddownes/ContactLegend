<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateAddressListResponse {
  /* string */
  public $list_id;
}

?>
