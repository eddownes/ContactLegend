<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateJobResponse {
  /* return_status */
  public $job_status;
}

?>
