<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class name_value {
  /* string */
  public $name;
  /* string */
  public $value;
}

?>
