<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CheckListStatus {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* string */
  public $list_id;
}

?>
