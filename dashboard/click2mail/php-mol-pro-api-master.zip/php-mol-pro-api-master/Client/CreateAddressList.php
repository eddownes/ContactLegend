<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateAddressList {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* int */
  public $data_template_id;
  /* ArrayOfArrayOfName_value */
  public $data;
}

?>
