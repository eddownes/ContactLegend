<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CheckJobStatusResponse {
  /* status_code */
  public $CheckJobStatusResult;
}

?>
