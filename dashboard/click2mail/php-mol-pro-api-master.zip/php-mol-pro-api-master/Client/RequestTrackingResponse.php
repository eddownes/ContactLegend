<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class RequestTrackingResponse {
  /* ArrayOfTracking_info */
  public $RequestTrackingResult;
}

?>
