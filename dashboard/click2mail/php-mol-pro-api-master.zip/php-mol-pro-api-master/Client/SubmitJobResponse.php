<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class SubmitJobResponse {
  /* status_code */
  public $submit_job_result;
}

?>
