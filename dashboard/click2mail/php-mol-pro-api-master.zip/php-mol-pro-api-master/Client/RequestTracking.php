<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class RequestTracking {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* int */
  public $jobId;
}

?>
