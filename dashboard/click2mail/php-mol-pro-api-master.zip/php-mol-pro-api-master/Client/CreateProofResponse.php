<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateProofResponse {
  /* string */
  public $preview_id;
}

?>
