<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class return_status {
  /* string */
  public $description;
  /* int */
  public $status_id;
  /* int */
  public $id;
}

?>
