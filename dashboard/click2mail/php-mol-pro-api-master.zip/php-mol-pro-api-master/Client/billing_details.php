<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class billing_details {
  /* string */
  public $bill_address1;
  /* string */
  public $bill_address2;
  /* string */
  public $bill_city;
  /* string */
  public $bill_company;
  /* string */
  public $bill_country;
  /* string */
  public $bill_exp_month;
  /* string */
  public $bill_exp_year;
  /* string */
  public $bill_name;
  /* string */
  public $bill_number;
  /* string */
  public $bill_state;
  /* string */
  public $bill_type;
  /* string */
  public $bill_zip;
}

?>
