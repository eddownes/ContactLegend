<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateProof {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* int */
  public $jobid;
}

?>
