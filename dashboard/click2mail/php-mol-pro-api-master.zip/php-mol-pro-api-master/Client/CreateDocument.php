<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateDocument {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* string */
  public $new_document_name;
  /* string */
  public $document_type;
  /* int */
  public $image_file_type;
  /* string */
  public $uploaded_file_id;
}

?>
