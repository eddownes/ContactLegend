<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class MergeDocuments {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* ArrayOfLong */
  public $documents;
  /* string */
  public $docname;
  /* string */
  public $document_type;
}

?>
