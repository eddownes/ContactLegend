<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class MergeDocumentsResponse {
  /* long */
  public $MergeDocumentsResult;
}

?>
