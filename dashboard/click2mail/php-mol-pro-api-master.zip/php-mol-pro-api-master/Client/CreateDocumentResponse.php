<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateDocumentResponse {
  /* return_status */
  public $document_creation_status;
}

?>
