<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CorrectAddress {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* ArrayOfAddress_details */
  public $addressold;
}

?>
