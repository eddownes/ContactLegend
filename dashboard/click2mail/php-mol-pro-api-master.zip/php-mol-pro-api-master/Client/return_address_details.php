<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class return_address_details {
  /* string */
  public $name;
  /* string */
  public $business;
  /* string */
  public $address;
  /* string */
  public $city;
  /* string */
  public $state;
  /* string */
  public $zip;
  /* string */
  public $ancillary_endorsement;
}

?>
