<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CreateJob {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* int */
  public $data_list_id;
  /* int */
  public $document_id;
  /* int */
  public $job_template_id;
  /* return_address_details */
  public $return_address;
}

?>
