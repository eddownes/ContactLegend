<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class tracking_info {
  /* string */
  public $Barcode;
  /* string */
  public $recipientAddress;
  /* string */
  public $status;
  /* dateTime */
  public $statDateTime;
  /* string */
  public $City;
  /* string */
  public $State;
}

?>
