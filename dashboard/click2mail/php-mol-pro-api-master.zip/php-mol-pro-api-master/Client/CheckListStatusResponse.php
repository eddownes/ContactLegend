<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CheckListStatusResponse {
  /* return_status */
  public $list_status;
}

?>
