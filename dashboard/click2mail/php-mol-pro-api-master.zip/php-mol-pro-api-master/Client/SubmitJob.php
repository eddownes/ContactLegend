<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class SubmitJob {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* int */
  public $job_id;
  /* billing_details */
  public $billing_details;
}

?>
