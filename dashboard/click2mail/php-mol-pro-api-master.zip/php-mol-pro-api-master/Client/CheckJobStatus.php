<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class CheckJobStatus {
  /* string */
  public $client_app_id;
  /* string */
  public $client_app_pwd;
  /* int */
  public $job_id;
}

?>
