<?php
/**
 * 
 * 
 * @package
 * @copyright
 */
class status_code {
  /* string */
  public $description;
  /* int */
  public $status_id;
}

?>
